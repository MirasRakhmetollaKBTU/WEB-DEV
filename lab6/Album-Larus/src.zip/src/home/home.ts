import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: "home.html",
  styleUrls: [`home.html`,],
})
export class Home {

}
